@echo off
set SCRIPT_DIR=%~dp0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%scripts\install-driver.ps1" -PackageDir "%SCRIPT_DIR%driver" -SkipBuild -TrustTestCertificate %*
