OpenA8DJ Windows Driver - Development Installer

STOP: this is an experimental Windows driver installer for controlled testing.
It is publicly downloadable, but it is not Microsoft-signed, not certified,
and not a production consumer installer.

This package can change the Windows Driver Store and bind a kernel driver to
USB\\VID_17CC&PID_1978. Kernel driver failures can crash or reboot Windows.
Use it only on a test machine with recovery access.

What is in this ZIP:
- install.cmd: elevated development installer entry point
- verify.cmd: post-install verification entry point
- uninstall.cmd: removal entry point
- driver\\OpenA8DJUsb.inf/cat/sys: test-signed driver package
- driver\\opena8djctl.exe: diagnostics/control CLI
- manifest files with hashes and signing state

Install (simple path):
1. Close audio applications and unplug the Audio 8 DJ.
2. In an Administrator Terminal run: shutdown /r /o /t 0
3. Choose Troubleshoot > Advanced options > Startup Settings > Restart,
   then press 7 (Disable driver signature enforcement).
4. Double-click the EXE, or run install.cmd from this extracted ZIP, and
   approve the UAC prompt.
5. If Windows Security asks, choose Install this driver software anyway.
6. Reconnect the Audio 8 DJ and wait for Windows to detect it.
7. Option 7 is one-boot only. Do not use -ForceInstallDespiteSecureBoot or
   combine option 7 with -EnableTestSigning.

Secure Boot limitation:
Windows blocks bcdedit /set testsigning on while Secure Boot is enabled.
Installing this test-signed package anyway can bind it to the Audio 8 DJ
but leave the device failed with Code 52 / 0xC0000428.
Use a Microsoft-signed package for Secure Boot systems.

Verify:
1. Run verify.cmd as Administrator.
2. Save the JSON output.
3. Run driver\\opena8djctl.exe surface.
4. Run driver\\opena8djctl.exe diagnostics.

Uninstall:
1. Run uninstall.cmd as Administrator.

Current limitations:
- This build is experimental and not Microsoft-signed.
- It is not the macOS OpenA8DJ driver and does not install macOS payloads.
- It is not yet a production-quality Windows DJ/audio driver.
- Full DVS/timecode, MIDI, ASIO, hotplug, sleep/wake, and clean-install
  validation remain release gates.

Do not use this on a production DJ system.
