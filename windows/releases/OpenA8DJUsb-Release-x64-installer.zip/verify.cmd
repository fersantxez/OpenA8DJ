@echo off
set SCRIPT_DIR=%~dp0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%scripts\verify-driver.ps1" -PackageDir "%SCRIPT_DIR%driver" -RunControlTool %*
